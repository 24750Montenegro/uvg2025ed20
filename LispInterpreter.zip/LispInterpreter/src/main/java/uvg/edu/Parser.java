package uvg.edu;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Parser {

    /**
     * Parsea la entrada y retorna una lista de expresiones (ASTs).
     */
    public List<AstNode> parse(String input) {
        List<String> tokens = tokenize(input);
        List<AstNode> expressions = new ArrayList<>();
        while (!tokens.isEmpty()) {
            expressions.add(readFromTokens(tokens));
        }
        return expressions;
    }

    /**
     * Separa la entrada en tokens, considerando paréntesis.
     */
    private List<String> tokenize(String input) {
        // Agrega espacios alrededor de paréntesis para separar correctamente
        input = input.replace("(", " ( ").replace(")", " ) ");
        String[] split = input.trim().split("\\s+");
        return new ArrayList<>(Arrays.asList(split));
    }

    /**
     * Lee un token y lo convierte en un AstNode, de forma recursiva para listas.
     */
    private AstNode readFromTokens(List<String> tokens) {
        if (tokens.isEmpty()) {
            throw new RuntimeException("Unexpected EOF while reading");
        }
        String token = tokens.remove(0);
        if ("(".equals(token)) {
            List<AstNode> list = new ArrayList<>();
            while (!tokens.get(0).equals(")")) {
                list.add(readFromTokens(tokens));
                if (tokens.isEmpty()) {
                    throw new RuntimeException("Expected ')'");
                }
            }
            tokens.remove(0); // elimina ")"
            return new AstNode(AstNode.Type.LIST, list);
        } else if (")".equals(token)) {
            throw new RuntimeException("Unexpected ')'");
        } else {
            return atom(token);
        }
    }

    /**
     * Convierte un token en un número o símbolo.
     */
    private AstNode atom(String token) {
        try {
            int number = Integer.parseInt(token);
            return new AstNode(AstNode.Type.NUMBER, number);
        } catch (NumberFormatException e) {
            return new AstNode(AstNode.Type.SYMBOL, token);
        }
    }
}

