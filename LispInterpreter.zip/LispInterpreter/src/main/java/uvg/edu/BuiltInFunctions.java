package uvg.edu;

import java.util.List;

public class BuiltInFunctions {

    public static int add(List<Integer> operands) {
        int sum = 0;
        for (int op : operands) {
            sum += op;
        }
        return sum;
    }

    public static int subtract(List<Integer> operands) {
        if (operands.isEmpty()) {
            throw new RuntimeException("No operands provided for subtraction");
        }
        // Si hay un solo operando, retorna su negativo
        if (operands.size() == 1) {
            return -operands.get(0);
        }
        int result = operands.get(0);
        for (int i = 1; i < operands.size(); i++) {
            result -= operands.get(i);
        }
        return result;
    }

    public static int multiply(List<Integer> operands) {
        int result = 1;
        for (int op : operands) {
            result *= op;
        }
        return result;
    }

    public static int divide(List<Integer> operands) {
        if (operands.isEmpty()) {
            throw new RuntimeException("No operands provided for division");
        }
        int result = operands.get(0);
        for (int i = 1; i < operands.size(); i++) {
            int op = operands.get(i);
            if (op == 0) {
                throw new ArithmeticException("Division by zero");
            }
            result /= op;
        }
        return result;
    }
}
