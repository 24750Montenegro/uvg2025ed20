package uvg.edu;


import java.util.ArrayList;
import java.util.List;

public class Evaluator {

    /**
     * Evalúa un nodo del AST.
     */
    public Object eval(AstNode node) {
        switch (node.getType()) {
            case NUMBER:
                return node.getValue();
            case LIST:
                List<AstNode> list = (List<AstNode>) node.getValue();
                if (list.isEmpty()) {
                    throw new RuntimeException("Cannot evaluate an empty list");
                }
                AstNode first = list.get(0);
                if (first.getType() != AstNode.Type.SYMBOL) {
                    throw new RuntimeException("The first element of a list must be a symbol (operator)");
                }
                String operator = (String) first.getValue();
                List<Integer> operands = new ArrayList<>();
                // Evalúa cada operando recursivamente
                for (int i = 1; i < list.size(); i++) {
                    Object result = eval(list.get(i));
                    if (result instanceof Integer) {
                        operands.add((Integer) result);
                    } else {
                        throw new RuntimeException("Operand is not a number: " + result);
                    }
                }
                return evalArithmetic(operator, operands);
            case SYMBOL:
                // No se espera evaluar símbolos aislados
                throw new RuntimeException("Unexpected symbol: " + node.getValue());
            default:
                throw new RuntimeException("Unknown AST node type");
        }
    }

    /**
     * Evalúa operaciones aritméticas en notación prefix.
     */
    private Object evalArithmetic(String op, List<Integer> operands) {
        switch (op) {
            case "+":
                return BuiltInFunctions.add(operands);
            case "-":
                return BuiltInFunctions.subtract(operands);
            case "*":
                return BuiltInFunctions.multiply(operands);
            case "/":
                return BuiltInFunctions.divide(operands);
            default:
                throw new RuntimeException("Unknown operator: " + op);
        }
    }
}

