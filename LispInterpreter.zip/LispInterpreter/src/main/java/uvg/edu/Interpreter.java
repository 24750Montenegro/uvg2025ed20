package uvg.edu;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Interpreter {

    public static void main(String[] args) {
        String filePath = "src/main/java/uvg/edu/sample.lisp";
        new Interpreter().run(filePath);
    }

    /**
     * Lee el archivo, parsea las expresiones y evalúa cada una.
     */
    private void run(String filePath) {
        try {
            String input = new String(Files.readAllBytes(Paths.get(filePath)), StandardCharsets.UTF_8);
            Parser parser = new Parser();
            List<AstNode> expressions = parser.parse(input);
            Evaluator evaluator = new Evaluator();
            for (AstNode expr : expressions) {
                Object result = evaluator.eval(expr);
                System.out.println(result);
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error en la evaluación: " + e.getMessage());
        }
    }
}
